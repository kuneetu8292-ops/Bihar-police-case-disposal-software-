/**
 * BPCDMS Backend
 * -----------------------------------------------------------------------
 * A tiny REST API that stores every record the frontend used to save
 * into the "Canva Sheet" (cases, IOs, messages, notifications, leave
 * applications) into a local SQLite database instead.
 *
 * The frontend's dataSdk shim (see public/index.html) talks to exactly
 * these 4 endpoints:
 *
 *   GET    /api/records        -> { isOk: true, data: [...] }
 *   POST   /api/records        -> { isOk: true, data: {...} }
 *   PUT    /api/records/:id    -> { isOk: true, data: {...} }
 *   DELETE /api/records/:id    -> { isOk: true }
 *
 * Every record is stored as a single JSON blob (the schema is
 * intentionally flexible, matching the original app's mixed
 * case / io / message / notification / leave record_type shapes).
 * -----------------------------------------------------------------------
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');

const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'bpcdms.db');

const app = express();

app.use(cors());
// Case images are stored as base64 data URIs (up to ~5MB files -> ~7MB
// base64 text), so we need a generous JSON body limit.
app.use(express.json({ limit: '20mb' }));

// ---------------------------------------------------------------------
// Database setup
// ---------------------------------------------------------------------
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS records (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    data       TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

function rowToRecord(row) {
  const record = JSON.parse(row.data);
  record.__backendId = String(row.id);
  return record;
}

// ---------------------------------------------------------------------
// API routes
// ---------------------------------------------------------------------

// GET all records
app.get('/api/records', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM records ORDER BY id ASC').all();
    res.json({ isOk: true, data: rows.map(rowToRecord) });
  } catch (e) {
    console.error('GET /api/records failed:', e);
    res.status(500).json({ isOk: false, error: { message: e.message } });
  }
});

// CREATE a record
app.post('/api/records', (req, res) => {
  try {
    const record = Object.assign({}, req.body || {});
    delete record.__backendId;
    const info = db
      .prepare('INSERT INTO records (data) VALUES (?)')
      .run(JSON.stringify(record));
    const row = db.prepare('SELECT * FROM records WHERE id = ?').get(info.lastInsertRowid);
    res.json({ isOk: true, data: rowToRecord(row) });
  } catch (e) {
    console.error('POST /api/records failed:', e);
    res.status(500).json({ isOk: false, error: { message: e.message } });
  }
});

// UPDATE a record
app.put('/api/records/:id', (req, res) => {
  try {
    const id = req.params.id;
    const existing = db.prepare('SELECT * FROM records WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ isOk: false, error: { message: 'Record not found' } });
    }
    const record = Object.assign({}, req.body || {});
    delete record.__backendId;
    db.prepare("UPDATE records SET data = ?, updated_at = datetime('now') WHERE id = ?").run(
      JSON.stringify(record),
      id
    );
    const row = db.prepare('SELECT * FROM records WHERE id = ?').get(id);
    res.json({ isOk: true, data: rowToRecord(row) });
  } catch (e) {
    console.error('PUT /api/records/:id failed:', e);
    res.status(500).json({ isOk: false, error: { message: e.message } });
  }
});

// DELETE a record
app.delete('/api/records/:id', (req, res) => {
  try {
    const id = req.params.id;
    const existing = db.prepare('SELECT * FROM records WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ isOk: false, error: { message: 'Record not found' } });
    }
    db.prepare('DELETE FROM records WHERE id = ?').run(id);
    res.json({ isOk: true });
  } catch (e) {
    console.error('DELETE /api/records/:id failed:', e);
    res.status(500).json({ isOk: false, error: { message: e.message } });
  }
});

// Simple health check (useful for hosting platforms like Render/Railway)
app.get('/api/health', (req, res) => {
  res.json({ isOk: true, status: 'running', time: new Date().toISOString() });
});

// ---------------------------------------------------------------------
// Serve the frontend
// ---------------------------------------------------------------------
app.use(express.static(path.join(__dirname, 'public')));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`BPCDMS backend running at http://localhost:${PORT}`);
  console.log(`SQLite database file: ${DB_PATH}`);
});
